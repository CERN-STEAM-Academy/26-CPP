/* SPDX-License-Identifier: GPL-3.0-or-later */
/* Copyright © 2023 GSI Helmholtzzentrum fuer Schwerionenforschung GmbH
 *                  Matthias Kretz <m.kretz@gsi.de>
 */

template <typename T> class mycomplex
{
public:
  mycomplex(T r, T i) : real(r), imag(i) {}

  constexpr mycomplex operator-() const { return {-real, -imag}; }
  constexpr mycomplex operator+() const { return *this; }

  friend constexpr mycomplex operator+(const mycomplex &a, const mycomplex &b)
  {
    return {a.real + b.real, a.imag + b.imag};
  }

  friend constexpr mycomplex operator*(const mycomplex &a, const mycomplex &b)
  {
    return {a.real * b.real - a.imag * b.imag, a.real * b.imag + a.imag * b.real};
  }

  friend constexpr T norm(const mycomplex &x)
  {
    return x.real * x.real + x.imag * x.imag;
  }

  T real, imag;
};
