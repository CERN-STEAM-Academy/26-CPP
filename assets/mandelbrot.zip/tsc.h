/* SPDX-License-Identifier: GPL-3.0-or-later */
/* Copyright © 2019-2023 GSI Helmholtzzentrum fuer Schwerionenforschung GmbH
 *                       Matthias Kretz <m.kretz@gsi.de>
 */

#ifndef TSC_H_
#define TSC_H_

#include <x86intrin.h>

#include <chrono>
#include <cmath>
#include <iomanip>
#include <iostream>

class time_stamp_counter
{
public:
  [[gnu::always_inline]] void start()
  {
    start_time = std::chrono::steady_clock::now();
    unsigned int tmp;
    start_tsc = __rdtscp(&tmp);
  }

  [[gnu::always_inline]] void stop()
  {
    unsigned int tmp;
    end_tsc = __rdtscp(&tmp);
    end_time = std::chrono::steady_clock::now();
  }

  uint64_t cycles() const { return end_tsc - start_tsc; }

  std::chrono::duration<float, std::milli> duration() const
  {
    return end_time - start_time;
  }

  friend std::ostream &operator<<(std::ostream &out, const time_stamp_counter &tsc)
  {
    double c = tsc.cycles();
    const auto last = out.precision(3);
    out << std::setw(8) << c;
    const auto lastf = out.setf(out.fixed, out.floatfield);
    out << " cycles = " << std::setprecision(1) << std::setw(8) << tsc.duration().count()
        << " ms";
    out.setf(lastf, out.floatfield);
    out.precision(last);
    return out;
  }

  struct speedup {
    float cycles;
    float chrono;

    friend std::ostream &operator<<(std::ostream &out, const speedup &s)
    {
      const auto last = out.precision(2);
      const float ratio = s.cycles / s.chrono;
      if (ratio > 1.005f or ratio < 0.995f) {
        out << s.cycles << "x (cycles), " << s.chrono << "x (ms)";
      } else {
        out << (s.cycles + s.chrono) * 0.5f << "x";
      }
      out.precision(last);
      return out;
    }
  };

  friend speedup operator/(const time_stamp_counter &reference,
                           const time_stamp_counter &tocompare)
  {
    return {float(reference.cycles()) / tocompare.cycles(),
            reference.duration() / tocompare.duration()};
  }

private:
  uint64_t start_tsc, end_tsc;
  std::chrono::steady_clock::time_point start_time, end_time;
};

#endif  // TSC_H_
