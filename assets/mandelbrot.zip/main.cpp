/* SPDX-License-Identifier: GPL-3.0-or-later */
/* Copyright © 2023 GSI Helmholtzzentrum fuer Schwerionenforschung GmbH
 *                  Matthias Kretz <m.kretz@gsi.de>
 */

#include "image.h"
#include "mandelbrot.h"
#include "tsc.h"

#include <charconv>
#include <fstream>
#include <iostream>
#include <string_view>
#include <vector>

template <typename T>
constexpr auto
from_chars(std::string_view s, T& value)
{
  return std::from_chars(s.data(), s.data() + s.size(), value);
}

int main(int argc, char **args_ptr)
{
  int iterations = 300;
  float x0 = -0.5f;
  float y0 = 0.f;
  float h = 2.f;
  std::string filename = "mandelbrot.ppm";

  const std::vector<std::string_view> args(args_ptr + 1, args_ptr + argc);
  if (args.size() > 0) {
    filename = args[0];
  }
  if (args.size() > 1) {
    from_chars(args[1], iterations);
  }
  if (args.size() > 2) {
    from_chars(args[2], x0);
  }
  if (args.size() > 3) {
    from_chars(args[3], y0);
    if (y0 < 0.f) {
      h = -2 * y0;
    } else {
      h = 0.1f;
    }
  }
  if (args.size() > 4) {
    from_chars(args[4], h);
  }


  auto info = [&](std::string_view text, const auto&... more) {
    ((std::cout << text << '(' << iterations << ", " << x0 << ", " << y0 << ", " << h
                     << ')') << ... << more);
  };

  time_stamp_counter timer0;
  timer0.start();
  auto img0 = mandelbrot<float>(iterations, x0, y0, h);
  timer0.stop();
  info("mandelbrot<     float >", ": ", timer0, '\n');
/*
  time_stamp_counter timer1;
  timer1.start();
  auto img1 = mandelbrot<floatv>(iterations, x0, y0, h);
  timer1.stop();
  info("mandelbrot<simd<float>>", ": ", timer1, '\n');
  std::cout << "Speedup: " << timer0 / timer1 << '\n';
  std::cout << "Equal: " << std::boolalpha << (img0 == img1) << '\n';
*/
  std::fstream file(filename,
                    std::ios_base::out | std::ios_base::binary | std::ios_base::trunc);
  write_image(img0, file);
  return 0;
}
