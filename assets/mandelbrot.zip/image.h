/* SPDX-License-Identifier: GPL-3.0-or-later */
/* Copyright © 2023 GSI Helmholtzzentrum fuer Schwerionenforschung GmbH
 *                  Matthias Kretz <m.kretz@gsi.de>
 */

#include <vector>
#include <ostream>

using Pixel = std::uint32_t;

class Image
{
  using PixelVector = std::vector<Pixel>;
  PixelVector pixels;

  int w, h;

public:
  using value_type = typename PixelVector::value_type;
  using allocator_type = typename PixelVector::allocator_type;
  using size_type = typename PixelVector::size_type;
  using difference_type = typename PixelVector::difference_type;
  using reference = typename PixelVector::reference;
  using const_reference = typename PixelVector::const_reference;
  using pointer = typename PixelVector::pointer;
  using const_pointer = typename PixelVector::const_pointer;
  using iterator = typename PixelVector::iterator;
  using const_iterator = typename PixelVector::const_iterator;

  // over-allocate 64 pixels, allowing mandelbrot() to write past end()
  Image(int width, int height) : pixels(width * height + 64), w(width), h(height) {}

  Image(const Image&) = default;
  Image(Image&&) noexcept = default;
  Image& operator=(const Image&) = default;
  Image& operator=(Image&&) noexcept = default;

  pointer data() { return pixels.data(); }
  const_pointer data() const { return pixels.data(); }

  pointer line(int y) { return pixels.data() + y * w; }
  const_pointer line(int y) const { return pixels.data() + y * w; }

  reference operator[](int x, int y) { return pixels[x + y * w]; }
  const_reference operator[](int x, int y) const { return pixels[x + y * w]; }

  reference front() { return pixels.front(); }
  const_reference front() const { return pixels.front(); }

  reference back() { return pixels.back(); }
  const_reference back() const { return pixels.back(); }

  iterator begin() { return pixels.begin(); }
  const_iterator begin() const { return pixels.begin(); }
  const_iterator cbegin() const { return pixels.cbegin(); }

  iterator end() { return pixels.begin() + (w * h); }
  const_iterator end() const { return pixels.begin() + (w * h); }
  const_iterator cend() const { return pixels.cbegin() + (w * h); }

  size_type size() const noexcept { return w * h; }
  int width() const noexcept { return w; }
  int height() const noexcept { return h; }

  friend bool operator==(const Image &, const Image &) = default;
};

void write_image(const Image &img, std::ostream &file)
{
  if constexpr (sizeof(Pixel) == 1) {
    file << "P5\n"                                  // filetype
         << img.width() << ' ' << img.height() << '\n'  // image size
         << "255\n";                                // max grayscale color value
    file.write(reinterpret_cast<const char *>(img.data()), img.size());
  } else if constexpr (sizeof(Pixel) == 4) {
    file << "P6\n"                                  // filetype
         << img.width() << ' ' << img.height() << '\n'  // image size
         << "255\n";                                // max for each color value
    for (int y = 0; y < img.height(); ++y) {
      for (int x = 0; x < img.width(); ++x) {
        file.write(reinterpret_cast<const char *>(&img[x, y]), 3);
      }
    }
  }
}
