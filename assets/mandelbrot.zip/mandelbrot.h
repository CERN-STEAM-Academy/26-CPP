/* SPDX-License-Identifier: GPL-3.0-or-later */
/* Copyright © 2023–2026 GSI Helmholtzzentrum fuer Schwerionenforschung GmbH
 *                       Matthias Kretz <m.kretz@gsi.de>
 */

#include <simd>

#include <memory>
#include <numbers>

#include "mycomplex.h"

namespace simd = std::simd;

using floatv = simd::vec<float>;
using uintv = simd::rebind_t<unsigned, floatv>;

template <typename T>
Image mandelbrot(unsigned max_iterations, float x0, float y0, const float h)
{
  Image image(1920, 1080);
  const float scale = h / image.height();

  x0 -= 0.5f * image.width() * scale;
  y0 -= 0.5f * h;

  for (int y = 0; y < image.height(); ++y) {
    auto c = mycomplex<T>(0, y0 + y * scale);
    for (int x = 0; x < image.width(); ++x) {
      // initialize c to the complex value corresponding to (x, y) in the image
      c.real = x0 + x * scale;

      // Iterate z_n+1 = z_n * z_n + c until it leaves the Mandelbrot set (>=4), otherwise
      // assume it's inside
      auto z = c;
      unsigned n = 0;
      for (; norm(z) < 4.f and n < max_iterations; ++n) {
        z = z * z + c;
      }

      // transform the number of iterations n into a pixel value
      Pixel color = 0;
      if (n < max_iterations) {
        using std::sin;
        using std::sqrt;

        const Pixel blue = (sin(3.9416f + sqrt(5.f + n * 0.2f)) + 1.1f) * (0.47619f * 0xff);
        const Pixel red = (sin(2.f + sqrt(7.f + n * 0.15f)) + 1.1f) * (0.47619f * 0xff);
        const Pixel green = (sin(2.8416f + sqrt(3.f + n * 0.33f)) + 1.1f) * (0.47619f * 0xff);
        color = (blue << 16) + (green << 8) + red;
      }
      image[x, y] = color;
    }
  }
  return image;
}
